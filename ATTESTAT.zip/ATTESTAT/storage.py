import os
import csv
from models import Operation

DATA_DIR = "data"
CSV_FILE = os.path.join(DATA_DIR, "operations.csv")


def ensure_data_dir():
    os.makedirs(DATA_DIR, exist_ok=True) # создает папку, если ее не было


def save_operations(operations: list[Operation]):
    if operations is None:
        return # Пустой return ничего не сохраняет

    ensure_data_dir() # Создаст папку, если ее нет

    try:
        with open(CSV_FILE, mode='w', newline='', encoding='utf-8') as f: 
            # проверяет, есть ли файл по данному пути
            # открывает, а после работы закрывает CSV_FILE с модом работы "w", с новой линией и энкодинг = утф-8
            # Теперь задаем порядок и имена столбцов в формате EXCEL
            fieldnames = ["amount", "category", "date", "comment", "type"]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            # Проверяем заголовки
            for op in operations:
                writer.writerow(op.to_dict())

    except (IOError, ValueError) as e:
        print(f"Ошибка при сохранении данных: {e}")


def load_operations() -> list[Operation]: # считывает файл
    operations = [] # инициализируем пустой список транзакций

    if not os.path.exists(CSV_FILE):
        return operations # Пустой список, если нет файла

    try:
        with open(CSV_FILE, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            # Создаем объект, который наполняем нашими данными
            for row in reader:  # row  это строчка словаря
                try:
                    op = Operation(
                        amount=float(row["amount"]),
                        category=row["category"],
                        date=row["date"],
                        comment=row.get("comment", ""),
                        op_type=row["type"]
                    )
                    operations.append(op)
                except ValueError as ve:
                    print(f"Пропущена некорректная запись: {ve}")

    except (IOError, csv.Error) as e:
        print(f"Ошибка при загрузке данных: {e}")

    return operations


def append_operation(operation: Operation):
    ensure_data_dir()

    file_exists = os.path.isfile(CSV_FILE)

    try:
        with open(CSV_FILE, mode='a', newline='', encoding='utf-8') as f:
            # Добавляем имена полей
            fieldnames = ["amount", "category", "date", "comment", "type"]
            writer = csv.DictWriter(f, fieldnames=fieldnames)

            if not file_exists:
                writer.writeheader()

            writer.writerow(operation.to_dict())

    except (IOError, ValueError) as e:
        print(f"Ошибка при добавлении операции: {e}")